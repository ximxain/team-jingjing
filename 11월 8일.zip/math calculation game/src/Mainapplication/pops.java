package Mainapplication;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.stage.Stage;

public class pops extends Mainapplication{
	@FXML
	Button closebtn;
	@FXML
	Label score;
	
	public void initialize(URL location, ResourceBundle resources) {
		System.out.println("11111");
		score.setText(timerBuffer+"\r정답률:"+(int)((double) valueAnswer / (double) stepLimit * 100.0) +"%");
	}
	
	public void close() { // 현재의 스테이지를 받아서 close를 해주어야 함
		pop = (Stage) closebtn.getScene().getWindow(); // 버튼을 통해서 현재 스테이지를 알아냄
		pop.close();
	}

}
