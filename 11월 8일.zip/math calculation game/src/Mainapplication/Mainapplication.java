package Mainapplication;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Random;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class Mainapplication extends Stopwatch{
	@FXML
	Label problem;
	@FXML
	Label input;
	@FXML
	Label question1;
	@FXML
	Label question2;
	
	@FXML
	Label answer;
	@FXML
	Label step;
	
	@FXML
	Button closebtn;
	@FXML
	Label score;
	
	@FXML
	Button easyMod;
	@FXML
	Button nomalMod;
	@FXML
	Button hardMod;
	@FXML
	Button superHardMod;
	@FXML
	Button start1;
	@FXML
	ImageView correctAnswer;
	
	static int intOne = 0;
	static int intTwo = 0;
	static int intAnswer = 0;
	static int presentStep = 0;
	static int stepLimit = 10;
	static String modChoice = "easy";
	
	static Stage mainStage;
	
	Random rd = new Random();
	
	
	
	
	
	static int value = 0;
	static String value2 = "0";
	public static int valueAnswer = 0;
	static int valueWrong = 0;
	
	public void choiceEasy() {
		modChoice = "easy";
	}
	public void choiceNomal() {
		modChoice = "nomal";
	}
	public void choiceHard() {
		modChoice = "hard";
	}
	public void choiceSuperHard() {
		modChoice = "super hard";
	}
	
	
	public void start() {
		mainStage = (Stage) start1.getScene().getWindow();
		
		problem();
		stopwatch(1);
	}
	
	public void problem() {
		if(presentStep >= stepLimit) {
			System.out.println("end");
			System.out.println(valueAnswer);
			System.out.println( "정답률: "+(int)((double) valueAnswer / (double) stepLimit * 100.0) + "%");
			stopwatch(0);
			System.out.format("Timer OFF! 경과 시간: [%s]%n", timerBuffer);
			endPop();
		} else {
			presentStep++;
			step.setText(presentStep+"/"+stepLimit);
			value = 0;
			value2 = "0";
			input.setText(value2);
			if(modChoice.equals("easy")) {
				intOne = rd.nextInt(18)+1;
				intTwo = rd.nextInt(18)+1;
			} else if(modChoice.equals("nomal")) {
				intOne = rd.nextInt(18)+10;
				intTwo = rd.nextInt(18)+10;
			} else if(modChoice.equals("hard")) {
				intOne = rd.nextInt(28)+10;
				intTwo = rd.nextInt(28)+10;
			} else if(modChoice.equals("super hard")) {
				intOne = rd.nextInt(28)+20;
				intTwo = rd.nextInt(28)+20;
			}
			question1.setText(""+intOne);
			question2.setText(""+intTwo);
			intAnswer = intOne * intTwo;
			answer.setText("????");
		}
	}
	
	public void input0(){
		if(value2.length()>9) {
			System.out.println("!!!");
		} else {
			if(value2.equals("0")) {
				value2 = null;
				value2 = "0";
			} else {
				value2 = value2 + "0";
			}

		}
		input.setText(value2);

	}
	
	
	public void input1(){
		if(value2.length()>9) {
			System.out.println("!!!");
		} else {
			if(value2.equals("0")) {
				value2 = null;
				value2 = "1";
			} else {
				value2 = value2 + "1";
			}

		}
		input.setText(value2);
//		if(value > 10000) {
//			System.out.println("�삤瑜�! �꼫臾� �겙 �닔!");
//		} else if(value >= 1000) {
//			value = value + 10000;
//		} else if(value >= 100) {
//			value = value + 1000;
//		} else if(value >= 10) {
//			value = value + 100;
//		} else if(value >= 1) {
//			value = value + 10;
//		} else if(value == 0) {
//			value = value + 1;
//		}
		
	}
	public void input2(){
		if(value2.length()>9) {
			System.out.println("!!!");
		} else {
			if(value2.equals("0")) {
				value2 = null;
				value2 = "2";
			} else {
				value2 = value2 + "2";
			}

		}
		input.setText(value2);

	}
	
	public void input3(){
		if(value2.length()>9) {
			System.out.println("!!!");
		} else {
			if(value2.equals("0")) {
				value2 = null;
				value2 = "3";
			} else {
				value2 = value2 + "3";
			}

		}
		input.setText(value2);

	}
	public void input4(){
		if(value2.length()>9) {
			System.out.println("!!!");
		} else {
			if(value2.equals("0")) {
				value2 = null;
				value2 = "4";
			} else {
				value2 = value2 + "4";
			}

		}
		input.setText(value2);

	}
	public void input5(){
		if(value2.length()>9) {
			System.out.println("!!!");
		} else {
			if(value2.equals("0")) {
				value2 = null;
				value2 = "5";
			} else {
				value2 = value2 + "5";
			}

		}
		input.setText(value2);

	}
	public void input6(){
		if(value2.length()>9) {
			System.out.println("!!!");
		} else {
			if(value2.equals("0")) {
				value2 = null;
				value2 = "6";
			} else {
				value2 = value2 + "6";
			}

		}
		input.setText(value2);

	}
	public void input7(){
		if(value2.length()>9) {
			System.out.println("!!!");
		} else {
			if(value2.equals("0")) {
				value2 = null;
				value2 = "7";
			} else {
				value2 = value2 + "7";
			}

		}
		input.setText(value2);

	}
	public void input8(){
		if(value2.length()>9) {
			System.out.println("!!!");
		} else {
			if(value2.equals("0")) {
				value2 = null;
				value2 = "8";
			} else {
				value2 = value2 + "8";
			}

		}
		input.setText(value2);

	}
	
	public void input9(){
		if(value2.length()>9) {
			System.out.println("!!!");
		} else {
			if(value2.equals("0")) {
				value2 = null;
				value2 = "9";
			} else {
				value2 = value2 + "9";
			}

		}
		input.setText(value2);

	}
	public void inputAnswer() {
		if(value2.equals(""+intAnswer)) {
			System.out.println("answer");
			String path = "src//resource/answer.png";
			try {
				FileInputStream fis = new FileInputStream(path);
				BufferedInputStream bis = new BufferedInputStream(fis);
				Image img = new Image(bis);
				correctAnswer.setImage(img);
				try {

					bis.close();
					fis.close();
					Thread t = new Thread(new Runnable() {

						@Override
						public void run() {
							try {
								Thread.sleep(1000);
								correctAnswer.setImage(null);
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();

							}
						}
					});

					t.start();
					valueAnswer++;
					problem();
				} catch (IOException e) {
					e.printStackTrace();
					System.out.println("img");
				}
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
			
		} else {
			System.out.println("wrong");
			String path = "src//resource//wrong.png";
			try {
				FileInputStream fis = new FileInputStream(path);
				BufferedInputStream bis = new BufferedInputStream(fis);
				Image img = new Image(bis);
				correctAnswer.setImage(img);
				try {

					bis.close();
					fis.close();
					Thread t = new Thread(new Runnable() {

						@Override
						public void run() {
							try {
								Thread.sleep(1000);
								correctAnswer.setImage(null);
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();

							}
						}
					});

					t.start();
					valueWrong++;
					problem();
				} catch (IOException e) {
					e.printStackTrace();
					System.out.println("img");
				}
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
			
		}
	}
	
	public void turnBack() {
		if(value2.length() == 0 || value2.equals("0")) {
			value2 = "0";
		} else {
			value2 = value2.substring(0, value2.length() - 1);
			if(value2.length() == 0) {
				value2 = "0";
			}
		}
		input.setText(value2);
	}
	
	public Stage pop;
	
	public void endPop() {
		// 메인 스테이지 취득, 전의 두가지 방법 중 두번째 방법

				// 새로운 스테이지 생성 (옵션 추가, 스타일)
				pop = new Stage(StageStyle.DECORATED); // 스테이지 옵션
				pop.initModality(Modality.WINDOW_MODAL); // 그 위에 뜨는 모달의 옵션
				pop.initOwner(mainStage); // 메인 스테이지 부여

				try {
					// 새로운 스테이지에 custom 레이아웃 불러오기
					Parent root = FXMLLoader.load(getClass().getResource("/Mainapplication/Pop.fxml"));

					// 씬에 추가
					Scene sc = new Scene(root);
					// 씬에 스타일 추가
					sc.getStylesheets().add(getClass().getResource("/app/application.css").toExternalForm());
					pop.setScene(sc);
					pop.setTitle("팝업 띄우기");
					pop.setResizable(false); // 창 사이즈 조절 차단

					// 보여주기
					pop.show();
				} catch (IOException e) {
					e.printStackTrace();
				}
	}
	

}
